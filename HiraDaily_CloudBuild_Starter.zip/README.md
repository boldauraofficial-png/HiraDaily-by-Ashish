# HiraDaily by Ashish - Flutter starter

This is the first runnable Flutter source version for Android.

## Build APK
1. Install Flutter SDK, Android Studio and Android SDK on a Windows/Mac/Linux computer.
2. Run: `flutter create hiradaily`
3. Replace the generated `pubspec.yaml` and `lib/main.dart` with the files in this package.
4. In the project folder run:
   - `flutter pub get`
   - `flutter run` (test on an Android phone with USB debugging)
   - `flutter build apk --release`
5. APK output: `build/app/outputs/flutter-apk/app-release.apk`

## Current prototype features
- Personal single-user work diary (no worker management)
- Monthly date-wise Hira quantity and per-entry rate
- Fixed/default rate toggle
- Monthly work total, Jama, Upad and remaining balance
- Maximum 2 Upad entries per calendar month
- Edit/delete daily entries and edit/delete cash history
- Local phone storage using shared_preferences

## Important
This is a starter prototype, not a production release. Data is currently stored locally on one phone and is not cloud-synced. Before Play Store release, add robust database/export/backup, app icon/splash assets, privacy policy, validation and device testing. The Upad limit is enforced when adding entries; deleting an entry frees a monthly slot.
